from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Use shared crossings utilities
from golfsim.simulation.crossings import (
    compute_crossings_from_files,
)

try:
    # Optional: project logging if available
    from golfsim.logging import init_logging
except Exception:  # pragma: no cover - optional
    def init_logging(_level: str = "INFO") -> None:  # fallback noop
        return None


def main() -> None:
    init_logging("INFO")

    parser = argparse.ArgumentParser(description="Crossings demo using reference logic (no modifications).")
    parser.add_argument(
        "--nodes_geojson",
        type=str,
        default="courses/pinetree_country_club/geojson/generated/holes_connected.geojson",
        help="GeoJSON FeatureCollection with ordered Point nodes (prefer holes_connected.geojson)."
    )
    parser.add_argument(
        "--holes_geojson",
        type=str,
        default=None,
        help="Optional holes polygons (not needed if nodes carry hole labels)."
    )
    parser.add_argument(
        "--config_json",
        type=str,
        default="courses/pinetree_country_club/config/simulation_config.json",
        help="Config JSON with golfer_18_holes_minutes and bev_cart_18_holes_minutes (optional)."
    )
    parser.add_argument("--v_fwd_mph", type=float, default=None, help="Override golfer speed (1->18) in mph.")
    parser.add_argument("--v_bwd_mph", type=float, default=None, help="Override beverage cart speed (18->1) in mph.")
    parser.add_argument("--bev_start", type=str, default="08:00:00")
    parser.add_argument("--groups_start", type=str, default="09:00:00")
    parser.add_argument("--groups_end", type=str, default="10:00:00")
    parser.add_argument("--groups_count", type=int, default=4)
    parser.add_argument("--random_seed", type=int, default=123)
    parser.add_argument("--tee_mode", type=str, choices=["interval", "random"], default="interval")
    parser.add_argument("--groups_interval_min", type=float, default=30.0)
    parser.add_argument("--out_dir", type=str, default=None, help="Optional output directory for summary files.")
    args = parser.parse_args()

    # Compute crossings using simplified minute-indexed logic via wrapper
    result = compute_crossings_from_files(
        nodes_geojson=args.nodes_geojson,
        holes_geojson=args.holes_geojson,
        config_json=args.config_json,
        v_fwd_mph=None,
        v_bwd_mph=None,
        bev_start=args.bev_start,
        groups_start=args.groups_start,
        groups_end=args.groups_end,
        groups_count=args.groups_count,
        random_seed=args.random_seed,
        tee_mode=args.tee_mode,
        groups_interval_min=args.groups_interval_min,
    )

    # Print concise console output
    print(f"Beverage cart start: {result['bev_start'].isoformat(sep=' ')}")
    for g in sorted(result["groups"], key=lambda r: r.get("tee_time")):
        tee = g.get("tee_time")
        if not g.get("crossed", True):
            print(f"Group {g['group']} tee {tee.isoformat(sep=' ')}: no crossings")
            continue
        for cr in g.get("crossings", []):
            node_idx = cr.get("node_index")
            ts = cr.get("timestamp")
            hole_disp = cr.get("hole") if cr.get("hole") is not None else "unknown"
            print(f"Group {g['group']} | node {node_idx} | {ts.isoformat(sep=' ')} | hole {hole_disp}")

    # Optional outputs
    out_dir = Path(args.out_dir) if args.out_dir else Path("outputs") / f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_reference_crossings"
    out_dir.mkdir(parents=True, exist_ok=True)
    # Write a minimal JSON summary
    summary_path = out_dir / "crossings_summary.json"
    serializable = {
        "bev_start": result["bev_start"].isoformat(),
        "groups": [
            {
                "group": g["group"],
                "tee_time": g.get("tee_time").isoformat() if g.get("tee_time") else None,
                "crossed": g.get("crossed", False),
                "crossings": [
                    {
                        "timestamp": cr.get("timestamp").isoformat() if cr.get("timestamp") else None,
                        "node_index": cr.get("node_index"),
                        "hole": cr.get("hole"),
                        "k_wraps": cr.get("k_wraps"),
                    }
                    for cr in g.get("crossings", [])
                ],
            }
            for g in result.get("groups", [])
        ],
    }
    summary_path.write_text(json.dumps(serializable, indent=2), encoding="utf-8")
    print(f"Saved crossings summary: {summary_path}")


if __name__ == "__main__":
    main()


